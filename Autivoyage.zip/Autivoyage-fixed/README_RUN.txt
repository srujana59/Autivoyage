Autivoyage Run Instructions

This is a static HTML/CSS/JavaScript project. No npm install, Python, PHP, database, or backend is needed.

How to run:
1. Open the folder: autiovoage final/autiovoage
2. Double-click autiovoage.html
3. Enter a name and click Submit
4. Click any game card

Recommended in VS Code:
1. Install the Live Server extension
2. Right-click autiovoage.html
3. Click Open with Live Server

Main page: autiovoage.html
Game pages: recognition_game.html, color_mathing.html, puzzle_game.html, sudoko_game.html, memory_game.html, maths.html
